# Default_list

An example of a priority list that can be used to generate ordered config files.

Notable mentions from this list:

- Programs that may/may not be in the environment tend to be removed (Ex. Dropbox)
- (Soon) I've updated and replaced filters, and will be adding them later.
